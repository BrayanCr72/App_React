import { StyleSheet, Text, View, Button,Alert, TextInput } from 'react-native';
import React, { useState } from 'react';
import axios from 'axios';
import { useRoute } from '@react-navigation/native';

const AppEdit = ({ navigation }) => {
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    text: {
      textAlign: 'center',
      fontSize: 20,
    },
    divider: {
      height: 1,
      width: '100%',
      backgroundColor: 'gray',
    },
  });

  const route = useRoute();
  const { id, producto, precio, cantidad, fecha,activo } = route.params;

  const [productoid, setId] = useState(id);
  const [prod, setProd] = useState(producto);
  const [price, setPrice] = useState(precio);
  const [cant, setCant] = useState(cantidad);
  const [date, setDate] = useState(fecha);
  const [active, setActive] = useState(activo);
  
  

  const handleProductoChange = (text) => {
    setProd(text);
  };

  const handlePrecioChange = (text) => {
    if (/^\d*$/.test(text)) {
      setPrice(text);
    }
  };

  const handleCantidadChange = (text) => {
    if (/^\d*$/.test(text)) {
      setCant(text);
    }
  };

  const handleFechaChange = (text) => {
    setDate(text);
  };


  const handleActivoChange = (text) => {
    setActive(text);
  };

  const handleSubmit = () => {

    if (!prod || !price || !cant || !date ) {
      Alert.alert('Error', 'Por favor, completa todos los campos.');
      return;
    }

    if (!/^[a-zA-Z\s]+$/.test(prod)) {
      Alert.alert('Error', 'El producto solo debe contener letras y espacios.');
      return;
    }

    if (!/^\d+$/.test(price)) {
      Alert.alert('Error', 'El precio solo debe contener números.');
      return;
    }

    if (!/^\d+$/.test(cant)) {
      Alert.alert('Error', 'La cantidad solo debe contener números.');
      return;
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      Alert.alert('Error', 'La fecha debe tener el formato YYYY-MM-DD.');
      return;
    }

    if (!/^\d{1}$/.test(active)) {
      Alert.alert('Error', 'El activo solo debe contener 1 o 0.');
      return;
    }


    console.log('Id:', id);
    console.log('Producto:', prod);
    console.log('Precio:', price);
    console.log('Cantidad:', cant);
    console.log('Fecha:', date);
    console.log('Activo:', active);

    //const url = 'http://192.168.100.251/AppReactWebSerExamen/ws_usuarios.php?modificar=modificarUsuario&id='+id+'&nombre='+name+'&edad='+age+'&fecha='+date+'&activo='+active+'&correo='+email;
    const url = `http://192.168.1.128:3000/modificarPedido?id=${id}&producto=${prod}&precio=${price}&cantidad=${cant}&fecha=${date}&activo=${active}`;
    //http://192.168.100.251/AppReactWebSerExamen/ws_usuarios.php?modificar=modificarUsuario&id=1&nombre=John&edad=30&fecha=2023-06-10&activo=1&correo=john@example.com
    axios
      .get(url)
      .then((response) => {
        alert('Se ha modificado el usuario con éxito!');
      })
      .catch((error) => {
        alert(error);
      });
  };

  return (
    <View>
      <TextInput
        placeholder="Producto"
        value={prod}
        onChangeText={handleProductoChange}
      />
      <TextInput
        placeholder="Precio"
        value={price.toString()}
        onChangeText={handlePrecioChange}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Cantidad"
        value={cant.toString()}
        onChangeText={handleCantidadChange}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Fecha"
        value={date}
        onChangeText={handleFechaChange}
      />
      <TextInput
        placeholder="Activo"
        value={active.toString()}
        onChangeText={handleActivoChange}
      />
      <Button title="Enviar" onPress={handleSubmit} />
    </View>
  );
};

export default AppEdit;
