import { StyleSheet, Text, View, Button, Alert, TextInput } from "react-native";
import React, { useState } from "react";
import axios from "axios";

const AppInsert = ({ navigation }) => {
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
    },
    text: {
      textAlign: "center",
      fontSize: 20,
    },
    divider: {
      height: 1,
      width: "100%",
      backgroundColor: "gray",
    },
  });

  const [producto, setProducto] = useState("");
  const [precio, setPrecio] = useState("");
  const [cantidad, setCantidad] = useState("");
  const [fecha, setFecha] = useState("");

  const handleProductoChange = (text) => {
    setProducto(text);
  };

  const handlePrecioChange = (text) => {
    if (/^\d*$/.test(text)) {
      setPrecio(text);
    }
  };
  const handleCantidadChange = (text) => {
    if (/^\d*$/.test(text)) {
      setCantidad(text);
    }
  };

  const handleFechaChange = (text) => {
    setFecha(text);
  };

  

  const handleSubmit = () => {
    if (!producto || !precio || !cantidad || !fecha) {
      alert("Todos los campos son requeridos");
      return;
    }

    if (!/^[a-zA-Z\s]+$/.test(producto)) {
      alert("El producto solo debe contener letras y espacios");
      return;
    }

    if (!/^\d+$/.test(precio)) {
      alert("El precio debe ser un número");
      return;
    }

    if (!/^\d+$/.test(cantidad)) {
      alert("La cantidad debe ser un número");
      return;
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
      alert("La fecha debe tener el formato YYYY-MM-DD");
      return;
    }

    console.log("Producto:", producto);
    console.log("Precio:", precio);
    console.log("Cantidad:", cantidad);
    console.log("Fecha:", fecha);

  

    //const url = `http://192.168.100.251/AppReactWebSerExamen/ws_usuarios.php?insertar=insertarUsuario&nombre=${nombre}&edad=${edad}&fecha=${fecha}&activo=${1}&correo=${correo}`;
    const url = `http://192.168.1.128:3000/insertarPedido?producto=${producto}&precio=${precio}&cantidad=${cantidad}&fecha=${fecha}&activo=${1}`;
    axios
      .get(url)
      .then((response) => {
        alert("¡Se ha insertado el usuario con éxito!");
      })
      .catch((error) => {
        alert(error);
        // Manejar el error si es necesario
      });
  };

  return (
    <View>
      <TextInput
        placeholder="Producto"
        value={producto}
        onChangeText={handleProductoChange}
      />
      <TextInput
        placeholder="Precio"
        value={precio}
        onChangeText={handlePrecioChange}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Cantidad"
        value={cantidad}
        onChangeText={handleCantidadChange}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Fecha (YYYY-MM-DD)"
        value={fecha}
        onChangeText={handleFechaChange}
      />
      <Button title="Enviar" onPress={handleSubmit} />
    </View>
  );
};

export default AppInsert;
