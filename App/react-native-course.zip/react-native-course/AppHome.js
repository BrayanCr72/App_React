import { StyleSheet, Text, View, Alert, Button } from 'react-native';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';

const AppHome = ({navigation}) => {
  fetchData();
  const styles = StyleSheet.create({
    container: {
      flex: 1, 
      justifyContent: 'center',
      alignItems: 'center',
    },
    text: {
      textAlign: 'center',
      fontSize: 20,
    },
    divider: {
      height: 1,
      width: '100%',
      backgroundColor: 'gray',
    },
  });

  
  const [pedidos, setPedidos] = useState([]);
    useEffect(() => {
        fetchData();
    }, []);
    

    async function fetchData() {
        try {
            //const response = await fetch('http://192.168.1.5/AppReactWebSer/ws_productos.php?listar=listarProductos');
            const response = await fetch('http://192.168.1.128:3000/listarPedidos');
            const data = await response.json();
            setPedidos(data.pedidos);
        } catch (error) {
            console.error(error);
        }
    }

    
    const deleteButtonClick = (id) => {

      Alert.alert(
        'Confirmar',
        '¿Estás seguro de que quieres eliminar este pedido?',
        [
          {
            text: 'Cancelar',
            style: 'cancel',
          },
          {
            text: 'Eliminar',
            onPress: () => {
              const url = 'http://192.168.1.128:3000/eliminarPedido?id=' + id;
              axios
                .get(url)
                .then((response) => {
                  alert('Se han borrado los datos del pedido con éxito!');
                  fetchData();
                })
                .catch((error) => {
                  alert(error);
                });
            },
            style: 'destructive',
          },
        ],
        { cancelable: false }
      );
  };


  const editButtonClick = (id,producto,precio,cantidad,fecha,activo) => {
      // Aqu� puedes realizar las operaciones que deseas al hacer clic en el bot�n.
      console.log(`Bot�n clickeado para el producto con ID: ${id}`);
      navigation.navigate('AppEdit', { id,producto,precio,cantidad,fecha,activo })
  };
    
      return (
        <View>
          <Text></Text>
          <Text style={styles.text}>Pedidos</Text>
          <Text></Text>
          {pedidos.map((pedido, index) => (
            <View key={index}>
              <Text style={styles.text}>{pedido.producto}</Text>
              <Text style={styles.text}>{pedido.precio}</Text>
              <Text style={styles.text}>{pedido.cantidad}</Text>
              <Text style={styles.text}>{pedido.fecha}</Text>
              <Text style={styles.text}>{pedido.activo}</Text>
              
              
              <Button
                title="Modificar"
                onPress={() => editButtonClick(pedido.id, pedido.producto, pedido.precio, pedido.cantidad, pedido.fecha, pedido.activo)}
              />
              <Button
                title="Eliminar"
                onPress={() => deleteButtonClick(pedido.id)}
              />

              <View style={styles.divider} />
              <Text></Text>
            </View>
          ))}
          
          <Button
        title="Insertar Pedido"
        onPress={() => navigation.navigate('AppInsert')}
      />
        </View>
      );  
};

export default AppHome;
