import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AppHome from './AppHome'; // Importa el componente al que deseas navegar
import AppInsert from './AppInsert'; // Importa el componente al que deseas navegar
import AppEdit from './AppEdit'; // Importa el componente al que deseas navegar
//comandos  npm install @react-navigation/native   npm install @react-navigation/stack  npm install axios
const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name="AppHome" component={AppHome} />
      <Stack.Screen name="AppInsert" component={AppInsert} />
      <Stack.Screen name="AppEdit" component={AppEdit} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;